/**
 *
 * @author
 *
 */
var ApplicationManager = (function () {
    function ApplicationManager() {
    }
    var d = __define,c=ApplicationManager,p=c.prototype;
    ApplicationManager.stageWidth = 480;
    ApplicationManager.stageHeight = 800;
    return ApplicationManager;
})();
egret.registerClass(ApplicationManager,'ApplicationManager');
//# sourceMappingURL=ApplicationManager.js.map