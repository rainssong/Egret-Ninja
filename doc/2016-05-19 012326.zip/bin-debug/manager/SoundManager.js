/// <reference path="../../libs/modules/res/RES.d.ts" />
/**
 * SoundManager
 */
var SoundManager = (function () {
    // public static throwSound: egret.Sound
    function SoundManager() {
    }
    var d = __define,c=SoundManager,p=c.prototype;
    SoundManager.playCutSound = function () {
        RES.getRes("cut_mp3").play(0, 1);
    };
    SoundManager.playDropSound = function () {
        RES.getRes("drop_mp3").play(0, 1);
    };
    SoundManager.playSplatterSound = function () {
        RES.getRes("splatter_mp3").play(0, 1);
    };
    //不用
    // public static playSwipSound()
    // {
    //     RES.getRes("swip_mp3").play(0, 1);
    // }
    SoundManager.playThrowSound = function () {
        RES.getRes("throw_mp3").play(0, 1);
    };
    return SoundManager;
})();
egret.registerClass(SoundManager,'SoundManager');
//# sourceMappingURL=SoundManager.js.map