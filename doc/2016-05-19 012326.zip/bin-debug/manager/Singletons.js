var Singletons = (function () {
    function Singletons() {
    }
    var d = __define,c=Singletons,p=c.prototype;
    Singletons.eventBus = new egret.EventDispatcher();
    return Singletons;
})();
egret.registerClass(Singletons,'Singletons');
//# sourceMappingURL=Singletons.js.map