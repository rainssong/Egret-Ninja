/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../view/LineDrawer.ts" />
/**
 * Test
 */
var LineDrawerTest = (function (_super) {
    __extends(LineDrawerTest, _super);
    function LineDrawerTest() {
        _super.call(this);
        this.ld = new view.LineDrawer();
        this.ld.startDraw(new egret.Point(0, 0));
        this.addChild(this.ld);
        this.ld.startDraw(new egret.Point(100, 100));
    }
    var d = __define,c=LineDrawerTest,p=c.prototype;
    /**
     * oef
     */
    p.onTouch = function (e) {
        switch (e.type) {
            case egret.TouchEvent.TOUCH_BEGIN:
                this.ld.startDraw(new egret.Point(e.stageX, e.stageY));
                break;
            case egret.TouchEvent.TOUCH_MOVE:
                this.ld.keepDraw(new egret.Point(e.stageX, e.stageY));
                break;
            case egret.TouchEvent.ENDED:
                break;
            default:
                break;
        }
    };
    /**
     * oef
     */
    p.oef = function () {
        this.ld.update();
    };
    return LineDrawerTest;
})(TestBase);
egret.registerClass(LineDrawerTest,'LineDrawerTest');
//# sourceMappingURL=LineDrawerTest.js.map