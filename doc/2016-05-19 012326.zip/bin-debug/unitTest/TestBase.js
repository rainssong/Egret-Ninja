/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../view/LineDrawer.ts" />
/**
 * Test
 */
var TestBase = (function (_super) {
    __extends(TestBase, _super);
    function TestBase() {
        _super.call(this);
        this.addEventListener(egret.Event.ENTER_FRAME, this.oef, this);
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdd, this);
    }
    var d = __define,c=TestBase,p=c.prototype;
    /**
     * onAdd
     */
    p.onAdd = function (e) {
        this.stage.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouch, this);
        this.stage.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouch, this);
        this.stage.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouch, this);
    };
    /**
     * oef
     */
    p.onTouch = function (e) {
    };
    /**
     * oef
     */
    p.oef = function () {
    };
    return TestBase;
})(egret.Sprite);
egret.registerClass(TestBase,'TestBase');
//# sourceMappingURL=TestBase.js.map