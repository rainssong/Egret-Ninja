/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../view/LineDrawer.ts" />
/// <reference path="../view/FruitView.ts" />
/// <reference path="../view/OrangeView.ts" />
/// <reference path="../view/SpaceView.ts" />
/// <reference path="TestBase.ts" />
/**
 * Test
 */
var FruitTest = (function (_super) {
    __extends(FruitTest, _super);
    function FruitTest() {
        _super.call(this);
        this.f = new view.OrangeView();
        this.f.x = 100;
        this.f.y = 100;
        // this.addChild(this.f);
        this.addChild(this.sv = new view.SpaceView);
        this.sv.addEntity(this.f);
        this.f2 = new view.OrangeView();
        this.f2.x = 200;
        this.f2.y = 100;
        this.sv.addEntity(this.f2);
        this.f3 = new view.OrangeView();
        this.f3.x = 300;
        this.f3.y = 100;
        this.sv.addEntity(this.f3);
    }
    var d = __define,c=FruitTest,p=c.prototype;
    /**
     * oef
     */
    p.onTouch = function (e) {
        switch (e.type) {
            case egret.TouchEvent.TOUCH_BEGIN:
                this.f.cut(0);
                this.f2.cut(45);
                this.f3.cut(90);
                break;
            case egret.TouchEvent.TOUCH_MOVE:
                break;
            case egret.TouchEvent.ENDED:
                break;
            default:
                break;
        }
    };
    /**
     * oef
     */
    p.oef = function () {
        this.sv.update(0.01);
    };
    return FruitTest;
})(TestBase);
egret.registerClass(FruitTest,'FruitTest');
//# sourceMappingURL=FruitTest.js.map