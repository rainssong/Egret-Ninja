var MathCore = (function () {
    function MathCore() {
    }
    var d = __define,c=MathCore,p=c.prototype;
    MathCore.randomSelect = function (aov) {
        return aov[Math.floor(aov.length * Math.random())];
    };
    MathCore.getRandomNumber = function (min, max) {
        return Math.random() * (max - min) + min;
    };
    MathCore.getRandomInt = function (min, max) {
        if (min === void 0) { min = -Infinity; }
        if (max === void 0) { max = Infinity; }
        return Math.floor(Math.random() * (max - min + 1) + min);
    };
    MathCore.getRangedNumber = function (num, min, max) {
        if (min === void 0) { min = -Infinity; }
        if (max === void 0) { max = Infinity; }
        if (min > max) {
            var tmp = min;
            min = max;
            max = tmp;
        }
        if (isNaN(min))
            min = -Infinity;
        if (isNaN(max))
            max = Infinity;
        return Math.max(min, Math.min(num, max));
    };
    MathCore.DEGREE_RADIAN_RATIO = 180 / Math.PI;
    MathCore.RADIAN_DEGREE_RATIO = Math.PI / 180;
    return MathCore;
})();
egret.registerClass(MathCore,'MathCore');
//# sourceMappingURL=MathCore.js.map