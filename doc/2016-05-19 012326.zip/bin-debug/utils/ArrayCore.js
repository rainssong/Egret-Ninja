var ArrayCore = (function (_super) {
    __extends(ArrayCore, _super);
    function ArrayCore() {
        _super.call(this);
    }
    var d = __define,c=ArrayCore,p=c.prototype;
    ArrayCore.concat = function (arr1, arr2) {
        var arr = arr1.slice();
        arr.push.apply(null, arr2);
        return arr;
    };
    ArrayCore.getIntArray = function (start, end) {
        if (start === void 0) { start = 0; }
        if (end === void 0) { end = 100; }
        var arr = [];
        for (var i = start; start < end ? (i <= end) : (i >= end); start < end ? i++ : i--) {
            arr.push(i);
        }
        return arr;
    };
    ArrayCore.getContentArray = function (content, length) {
        if (length === void 0) { length = 0; }
        var arr = [];
        if (length == 0)
            return arr;
        for (var i = 0; i < length; i++) {
            arr.push(content);
        }
        return arr;
    };
    ArrayCore.forEach = function (target, fun) {
        for (var t_key_a in target) {
            var t = target[t_key_a];
            t[fun]();
        }
    };
    ArrayCore.getRandomizedArray = function (arr) {
        var outputArr = arr.slice();
        var i = outputArr.length;
        var temp;
        var indexA = 0;
        var indexB = 0;
        while (i) {
            indexA = i - 1;
            indexB = Math.floor(Math.random() * i);
            i--;
            if (indexA == indexB)
                continue;
            temp = outputArr[indexA];
            outputArr[indexA] = outputArr[indexB];
            outputArr[indexB] = temp;
        }
        return outputArr;
    };
    ArrayCore.getLightRandomizedArray = function (arr, times) {
        if (times === void 0) { times = 1; }
        var outputArr = arr.slice();
        var length = outputArr.length;
        for (var i = 0; i < length - 1; i++) {
            if (Math.random() > 0.5) {
                var temp = outputArr[i];
                outputArr[i] = outputArr[i + 1];
                outputArr[i + 1] = temp;
            }
        }
        return outputArr;
    };
    ArrayCore.switchElements = function (arr, index1, index2) {
        var elementA = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = elementA;
    };
    ArrayCore.sum = function (arr) {
        var nSum = 0;
        for (var i = 0; i < arr.length; i++) {
            if (typeof (arr[i]) == "number") {
                nSum += arr[i];
            }
        }
        return nSum;
    };
    ArrayCore.vectorToArray = function (vector) {
        var array = new Array();
        var callback = function (item, index, vector) {
            array.push(item);
            return true;
        };
        vector.every(callback);
        return array;
    };
    ArrayCore.arrayToVector = function (array) {
        return Array(array);
    };
    ArrayCore.merge = function (arr1, arr2) {
        var arr = arr1.slice();
        for (var i = 0; i < arr2.length; i++) {
            if (arr.indexOf(arr2[i]) >= 0)
                continue;
            else
                arr.push(arr2[i]);
        }
        return arr;
    };
    ArrayCore.removeByElement = function (arr, element) {
        if (arr.indexOf(element) > -1)
            arr.splice(arr.indexOf(element), 1);
    };
    return ArrayCore;
})(egret.HashObject);
egret.registerClass(ArrayCore,'ArrayCore');
//# sourceMappingURL=ArrayCore.js.map