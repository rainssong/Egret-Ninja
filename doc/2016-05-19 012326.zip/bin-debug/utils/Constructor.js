function construction(cls, params) {
    if (params === void 0) { params = null; }
    switch (params.length) {
        case 0:
            return new cls();
        case 1:
            return new cls(params[0]);
        case 2:
            return new cls(params[0], params[1]);
        case 3:
            return new cls(params[0], params[1], params[2]);
        case 4:
            return new cls(params[0], params[1], params[2], params[3]);
        default:
            return null;
    }
}
//# sourceMappingURL=Constructor.js.map