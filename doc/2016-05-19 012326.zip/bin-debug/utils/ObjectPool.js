/// <reference path="Constructor.ts" />
var ObjectPool = (function () {
    function ObjectPool(value) {
        this._template = value;
        this._list = new Array();
    }
    var d = __define,c=ObjectPool,p=c.prototype;
    p.getObject = function (params) {
        if (params === void 0) { params = null; }
        if (this._list.length > 0) {
            return this._list.shift();
        }
        return construction(this._template, params);
    };
    p.returnObject = function (value) {
        this._list.push(value);
    };
    p.dispose = function () {
        this._list = null;
        this._template = null;
    };
    ObjectPool.getPool = function (value) {
        if (!ObjectPool._pool[value]) {
            ObjectPool._pool[value] = new ObjectPool(value);
        }
        return ObjectPool._pool[value];
    };
    ObjectPool.getObject = function (cls, params) {
        if (params === void 0) { params = []; }
        return ObjectPool.getPool(cls).getObject(params);
    };
    ObjectPool.returnObject = function (value) {
        return ObjectPool.getPool(value.constructor).returnObject(value);
    };
    ObjectPool.dispose = function (cls) {
        if (cls === void 0) { cls = null; }
        if (cls)
            ObjectPool.getPool(cls).dispose();
        else
            ObjectPool._pool = [];
    };
    ObjectPool._pool = new Array();
    return ObjectPool;
})();
egret.registerClass(ObjectPool,'ObjectPool');
//# sourceMappingURL=ObjectPool.js.map