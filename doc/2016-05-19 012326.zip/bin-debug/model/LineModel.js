var model;
(function (model) {
    var LineModel = (function (_super) {
        __extends(LineModel, _super);
        function LineModel(sp, ep, thickness) {
            if (thickness === void 0) { thickness = 2; }
            _super.call(this);
            this.thickness = 1;
            this.alpha = 1;
            this.color = 0xffffff;
            this.sp = sp;
            this.ep = ep;
            this.thickness = thickness;
        }
        var d = __define,c=LineModel,p=c.prototype;
        p.update = function () {
            this.thickness--;
            this.alpha -= 0.1;
        };
        return LineModel;
    })(egret.HashObject);
    model.LineModel = LineModel;
    egret.registerClass(LineModel,'model.LineModel');
})(model || (model = {}));
//# sourceMappingURL=LineModel.js.map