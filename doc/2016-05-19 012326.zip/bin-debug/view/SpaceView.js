var view;
(function (view) {
    /**
     * 简易物理空间
     */
    var SpaceView = (function (_super) {
        __extends(SpaceView, _super);
        function SpaceView() {
            _super.call(this);
            this.gravity = 9.8;
            this._entitys = new Array();
        }
        var d = __define,c=SpaceView,p=c.prototype;
        p.update = function (deltaTime) {
            if (deltaTime === void 0) { deltaTime = 1 / 60; }
            for (var entity_key_a in this._entitys) {
                var entity = this._entitys[entity_key_a];
                entity.update(deltaTime);
            }
        };
        p.addEntity = function (entity) {
            this.addChildAt(entity, Math.max(entity.z, 0));
            entity.environment = this;
            if (this._entitys.indexOf(entity) == -1)
                this._entitys.push(entity);
        };
        p.removeEntity = function (entity) {
            this.removeChild(entity);
            entity.environment = null;
            var index = this._entitys.indexOf(entity);
            if (index >= 0)
                this._entitys.splice(index, 1);
        };
        p.removeAllEntity = function () {
            while (this._entitys.length) {
                this.removeEntity(this._entitys[0]);
            }
        };
        d(p, "entitys"
            ,function () {
                return this._entitys;
            }
        );
        p.destroy = function () {
            this.removeAllEntity();
        };
        return SpaceView;
    })(egret.Sprite);
    view.SpaceView = SpaceView;
    egret.registerClass(SpaceView,'view.SpaceView');
})(view || (view = {}));
//# sourceMappingURL=SpaceView.js.map