/// <reference path="EntityView.ts" />
var view;
(function (view) {
    var LifeEntityView = (function (_super) {
        __extends(LifeEntityView, _super);
        function LifeEntityView() {
            _super.call(this);
            this._lifeTime = 0;
        }
        var d = __define,c=LifeEntityView,p=c.prototype;
        p.update = function (deltaTime) {
            if (deltaTime === void 0) { deltaTime = 1 / 60; }
            this._lifeTime -= deltaTime;
            if (this._lifeTime <= 0)
                this.remove();
        };
        return LifeEntityView;
    })(view.EntityView);
    view.LifeEntityView = LifeEntityView;
    egret.registerClass(LifeEntityView,'view.LifeEntityView');
})(view || (view = {}));
//# sourceMappingURL=LifeEntityView.js.map