/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../model/LineModel.ts" />
var view;
(function (view) {
    var LineDrawer = (function (_super) {
        __extends(LineDrawer, _super);
        function LineDrawer() {
            _super.call(this);
            this._sp = null;
            this._cp = null;
            this._shape = new egret.Shape();
            this._lines = new Array();
            this.addChild(this._shape);
        }
        var d = __define,c=LineDrawer,p=c.prototype;
        p.startDraw = function (p) {
            this._sp = p;
            this._cp = p;
        };
        p.keepDraw = function (p) {
            this._sp = this._cp;
            this._cp = p;
            var l = new model.LineModel(this._sp, this._cp, 10);
            l.alpha = 1;
            this._lines.push(l);
        };
        p.update = function () {
            this._shape.graphics.clear();
            for (var i = this._lines.length - 1; i >= 0; i--) {
                var l = this._lines[i];
                this._shape.graphics.lineStyle(l.thickness + 4, l.color * 0.5, l.alpha * 0.8);
                this._shape.graphics.moveTo(l.sp["x"], l.sp["y"]);
                this._shape.graphics.lineTo(l.ep["x"], l.ep["y"]);
                // 减少作画，提高效率
                // this._shape.graphics.lineStyle(l.thickness,l.color);
                // this._shape.graphics.moveTo(l.sp["x"],l.sp["y"]);
                // this._shape.graphics.lineTo(l.ep["x"],l.ep["y"]);
                l.update();
                if (l.thickness <= 0)
                    this._lines.splice(i, 1);
            }
        };
        d(p, "cp"
            ,function () {
                return this._cp;
            }
        );
        d(p, "sp"
            ,function () {
                return this._sp;
            }
        );
        p.destroy = function () {
            this._lines.length = 0;
        };
        return LineDrawer;
    })(egret.Sprite);
    view.LineDrawer = LineDrawer;
    egret.registerClass(LineDrawer,'view.LineDrawer');
})(view || (view = {}));
//# sourceMappingURL=LineDrawer.js.map