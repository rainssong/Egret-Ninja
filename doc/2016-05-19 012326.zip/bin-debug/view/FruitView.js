/// <reference path="EntityView.ts" />
/// <reference path="BreakFruitView.ts" />
/// <reference path="JuiceView.ts" />
/// <reference path="../utils/ObjectPool.ts" />
/// <reference path="../utils/MathCore.ts" />
/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../../libs/modules/particle/particle.d.ts" />
var view;
(function (view) {
    var FruitView = (function (_super) {
        __extends(FruitView, _super);
        function FruitView() {
            _super.call(this);
            this._color = 0;
            this._health = 1;
            this._score = 10;
            this._skin = new egret.Bitmap();
            this.addChild(this._skin);
        }
        var d = __define,c=FruitView,p=c.prototype;
        p.reset = function () {
            _super.prototype.reset.call(this);
            this._health = 1;
        };
        p.update = function (deltaTime) {
            if (deltaTime === void 0) { deltaTime = 1 / 60; }
            if (this.y > ApplicationManager.stageHeight + 100) {
                Singletons.eventBus.dispatchEvent(new egret.Event("miss"));
                //				SoundManager.getInstance().playSound("drop");
                this.remove();
            }
            if (this.x < -0 && this.speed.x < 0)
                this.speed.x *= -1;
            if (this.x > ApplicationManager.stageWidth && this.speed.x > 0)
                this.speed.x *= -1;
            _super.prototype.update.call(this, deltaTime);
        };
        p.cut = function (angleDegree) {
            if (angleDegree === void 0) { angleDegree = 0; }
            this._health--;
            Singletons.eventBus.dispatchEvent(new egret.Event("cut", false, false, this._score));
            if (this._health == 0)
                this.break2(angleDegree);
            return true;
        };
        p.getScore = function () {
            return this._score;
        };
        p.break2 = function (angleDegree) {
            if (angleDegree === void 0) { angleDegree = NaN; }
            if (this._environment == null)
                return;
            this.rotation = angleDegree + 90;
            if (this.speed.y < 0)
                this.speed.y = 5;
            //			SoundManager.getInstance().playSound("splatter");
            var bv;
            var p;
            if (this.backTex) {
                bv = ObjectPool.getObject(view.BreakFruitView);
                bv.texture = this.backTex;
                bv.rotation = this.rotation;
                // this.addChild(bv)
                p = this.localToGlobal(this.backOffset.x, this.backOffset.y);
                bv.reset();
                bv.x = p.x;
                bv.y = p.y;
                bv.z = 1;
                console.log(this.x, bv.x);
                bv.angSpeed = this.angSpeed - MathCore.getRandomNumber(30, 130);
                bv.speed.copyFrom(this.speed);
                bv.speed.x += (bv.x - this.x) * 4;
                bv.speed.y += (bv.y - this.y) * 4;
                this._environment.addEntity(bv);
            }
            if (this.frontTex) {
                bv = ObjectPool.getObject(view.BreakFruitView);
                bv.reset();
                bv.texture = this.frontTex;
                bv.rotation = this.rotation;
                var p = this.localToGlobal(this.frontOffset.x, this.frontOffset.y);
                bv.x = p.x;
                bv.y = p.y;
                bv.angSpeed = this.angSpeed + MathCore.getRandomNumber(30, 130);
                ;
                bv.speed.copyFrom(this.speed);
                bv.speed.x += (bv.x - this.x) * 4;
                bv.speed.y += (bv.y - this.y) * 4;
                this._environment.addEntity(bv);
            }
            if (this.juiceTex) {
                var jv = ObjectPool.getObject(view.JuiceView);
                jv.texture = this.juiceTex;
                p = this.localToGlobal(this.juiceOffset.x, this.juiceOffset.y);
                jv.x = p.x;
                jv.y = p.y;
                jv.z = 0;
                jv.rotation = this.rotation;
                this._environment.addEntity(jv);
            }
            if (this.particleTex) {
                // var pv: particle.GravityParticleSystem = ObjectPool.getObject(particle.GravityParticleSystem,RES.getRes(this.particleTex), RES.getRes("particle_json"));
                var pv = ObjectPool.getObject(particle.GravityParticleSystem, [RES.getRes("particle_png"), RES.getRes("particle_json")]);
                pv.changeTexture(this.particleTex);
                pv.x = this.x;
                pv.y = this.y;
                this._environment.addChildAt(pv, 10);
                pv.start(10);
                pv.addEventListener(egret.Event.COMPLETE, this.onParticleComplete, this);
            }
            Singletons.eventBus.dispatchEvent(new egret.Event("break2"));
            //			egret.log("destroy","break2");
            this.remove();
        };
        /**
         * onParticleComplete
         */
        p.onParticleComplete = function (e) {
            var pv = e.currentTarget;
            if (pv.parent)
                pv.parent.removeChild(pv);
            ObjectPool.returnObject(pv);
        };
        d(p, "color"
            ,function () {
                return this._color;
            }
        );
        return FruitView;
    })(view.EntityView);
    view.FruitView = FruitView;
    egret.registerClass(FruitView,'view.FruitView');
})(view || (view = {}));
//# sourceMappingURL=FruitView.js.map