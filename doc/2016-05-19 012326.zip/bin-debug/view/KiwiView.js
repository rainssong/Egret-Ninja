/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../../libs/modules/res/res.d.ts" />
/// <reference path="FruitView.ts" />
var view;
(function (view) {
    var KiwiView = (function (_super) {
        __extends(KiwiView, _super);
        function KiwiView() {
            _super.call(this);
            this._skin.texture = RES.getRes("kiwi_png");
            this._type = "kiwi";
            // this._color = 0xFFDC88;
            this._skin.x = -44;
            this._skin.y = -34;
            this.frontTex = RES.getRes("kiwif_png");
            this.backTex = RES.getRes("kiwib_png");
            this.juiceTex = RES.getRes("kiwij_png");
            this.particleTex = RES.getRes("kiwip_png");
            this.backOffset = new egret.Point(10, 0);
            this.frontOffset = new egret.Point(-10, 0);
            this.juiceOffset = new egret.Point(0, 0);
        }
        var d = __define,c=KiwiView,p=c.prototype;
        return KiwiView;
    })(view.FruitView);
    view.KiwiView = KiwiView;
    egret.registerClass(KiwiView,'view.KiwiView');
})(view || (view = {}));
//# sourceMappingURL=KiwiView.js.map