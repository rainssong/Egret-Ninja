/// <reference path="../../libs/modules/egret/egret.d.ts" />
var view;
(function (view) {
    var EntityView = (function (_super) {
        __extends(EntityView, _super);
        function EntityView() {
            _super.call(this);
            this._type = "entity";
            this.speed = new egret.Point();
            this.velocity = new egret.Point();
            this.angSpeed = 0;
            this.z = 10;
            this.init();
        }
        var d = __define,c=EntityView,p=c.prototype;
        p.init = function () {
            this.reset();
        };
        p.reset = function () {
        };
        p.update = function (deltaTime) {
            if (deltaTime === void 0) { deltaTime = 1 / 60; }
            if (this._environment == null)
                return;
            this.speed.y += this._environment.gravity * deltaTime;
            this.x += this.speed.x * deltaTime;
            this.y += this.speed.y * deltaTime;
            this.rotation += this.angSpeed * deltaTime;
        };
        p.remove = function () {
            if (this._environment)
                this._environment.removeEntity(this);
            ObjectPool.returnObject(this);
        };
        d(p, "environment"
            ,function () {
                return this._environment;
            }
            ,function (value) {
                this._environment = value;
            }
        );
        return EntityView;
    })(egret.Sprite);
    view.EntityView = EntityView;
    egret.registerClass(EntityView,'view.EntityView');
})(view || (view = {}));
//# sourceMappingURL=EntityView.js.map