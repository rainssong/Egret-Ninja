/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="LifeEntityView.ts" />
var view;
(function (view) {
    var FlashView = (function (_super) {
        __extends(FlashView, _super);
        function FlashView() {
            _super.call(this);
        }
        var d = __define,c=FlashView,p=c.prototype;
        p.init = function () {
            this._skin = new egret.Bitmap(RES.getRes("flash_png"));
            this._skin.fillMode = egret.BitmapFillMode.SCALE;
            this._skin.x = -this._skin.width * 0.5;
            this._skin.y = -this._skin.height * 0.5;
            this.addChild(this._skin);
            _super.prototype.init.call(this);
        };
        /**
         * reset
         */
        p.reset = function () {
            this._lifeTime = 0.3;
            this._skin.alpha = 1;
        };
        p.update = function (deltaTime) {
            if (deltaTime === void 0) { deltaTime = 1 / 60; }
            _super.prototype.update.call(this, deltaTime);
            if (this._lifeTime <= 0.3) {
                this._skin.alpha = this._lifeTime * 3.3;
            }
        };
        return FlashView;
    })(view.LifeEntityView);
    view.FlashView = FlashView;
    egret.registerClass(FlashView,'view.FlashView');
})(view || (view = {}));
//# sourceMappingURL=FlashView.js.map