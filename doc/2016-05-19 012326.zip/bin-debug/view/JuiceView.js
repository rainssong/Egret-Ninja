/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="LifeEntityView.ts" />
var view;
(function (view) {
    var JuiceView = (function (_super) {
        __extends(JuiceView, _super);
        function JuiceView() {
            _super.call(this);
        }
        var d = __define,c=JuiceView,p=c.prototype;
        p.init = function () {
            this._skin = new egret.Bitmap();
            this._skin.fillMode = egret.BitmapFillMode.SCALE;
            this.addChild(this._skin);
            _super.prototype.init.call(this);
        };
        /**
         * reset
         */
        p.reset = function () {
            this._lifeTime = 6;
            this._skin.alpha = 0.7;
        };
        p.update = function (deltaTime) {
            if (deltaTime === void 0) { deltaTime = 1 / 60; }
            _super.prototype.update.call(this, deltaTime);
            //alpha=life*speed
            if (this._lifeTime <= 0.7 / 0.25) {
                this._skin.alpha = this._lifeTime * 0.25;
                this.y += deltaTime * 5;
            }
        };
        d(p, "texture"
            ,function () {
                return this._skin.texture;
            }
            ,function (value) {
                this._skin.texture = value;
                this._skin.x = -this._skin.width * 0.5;
                this._skin.y = -this._skin.height * 0.5;
                this.reset();
            }
        );
        return JuiceView;
    })(view.LifeEntityView);
    view.JuiceView = JuiceView;
    egret.registerClass(JuiceView,'view.JuiceView');
})(view || (view = {}));
//# sourceMappingURL=JuiceView.js.map