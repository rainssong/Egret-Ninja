var view;
(function (view) {
    var BreakFruitView = (function (_super) {
        __extends(BreakFruitView, _super);
        function BreakFruitView() {
            _super.call(this);
            this._skin = new egret.Bitmap();
            this.addChild(this._skin);
        }
        var d = __define,c=BreakFruitView,p=c.prototype;
        d(p, "skin"
            ,function () {
                return this._skin;
            }
        );
        d(p, "texture"
            ,function () {
                return this._skin.texture;
            }
            ,function (value) {
                this._skin.texture = value;
                ;
                this._skin.x = -this._skin.width * 0.5;
                this._skin.y = -this._skin.height * 0.5;
            }
        );
        return BreakFruitView;
    })(view.EntityView);
    view.BreakFruitView = BreakFruitView;
    egret.registerClass(BreakFruitView,'view.BreakFruitView');
})(view || (view = {}));
//# sourceMappingURL=BreakFruitView.js.map