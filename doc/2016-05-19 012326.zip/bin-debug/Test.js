/// <reference path="../libs/modules/egret/egret.d.ts" />
/// <reference path="view/LineDrawer.ts" />
/**
 * Test
 */
var Test = (function (_super) {
    __extends(Test, _super);
    function Test() {
        _super.call(this);
        this.ld = new view.LineDrawer();
        this.ld.startDraw(new egret.Point(0, 0));
        this.addChild(this.ld);
        this.addEventListener(egret.Event.ENTER_FRAME, this.oef, this);
        this.ld.startDraw(new egret.Point(100, 100));
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdd, this);
    }
    var d = __define,c=Test,p=c.prototype;
    /**
     * onAdd
     */
    p.onAdd = function (e) {
        this.stage.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onMouse, this);
    };
    /**
     * oef
     */
    p.onMouse = function (e) {
        this.ld.keepDraw(new egret.Point(e.stageX, e.stageY));
    };
    /**
     * oef
     */
    p.oef = function () {
        // this.ld.keepDraw(new egret.Point(Math.random() * 100, Math.random() * 100));
        this.ld.update();
    };
    return Test;
})(egret.Sprite);
egret.registerClass(Test,'Test');
//# sourceMappingURL=Test.js.map