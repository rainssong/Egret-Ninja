/// <reference path="../libs/modules/egret/egret.d.ts" />
/// <reference path="view/LineDrawer.ts" />


/**
 * Test
 */
class Test extends egret.Sprite
{
    public ld: view.LineDrawer
    public constructor()
    {
        super();

        this.ld = new view.LineDrawer();
        this.ld.startDraw(new egret.Point(0, 0));


        this.addChild(this.ld);

        this.addEventListener(egret.Event.ENTER_FRAME, this.oef, this)
        
        this.ld.startDraw(new egret.Point(100, 100));
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdd,this);
    }

    /**
     * onAdd
     */
    public onAdd(e:egret.Event) {
        this.stage.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onMouse, this)
    }    

    /**
     * oef
     */
    public onMouse(e: egret.TouchEvent)
    {
        
        this.ld.keepDraw(new egret.Point(e.stageX, e.stageY));
    }
    /**
     * oef
     */
    public oef()
    {
        // this.ld.keepDraw(new egret.Point(Math.random() * 100, Math.random() * 100));
        this.ld.update();
    }
}