/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../view/LineDrawer.ts" />


/**
 * Test
 */
class TestBase extends egret.Sprite
{
    
    public constructor()
    {
        super();

        
        this.addEventListener(egret.Event.ENTER_FRAME, this.oef, this)
        
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAdd,this);
    }

    /**
     * onAdd
     */
    public onAdd(e:egret.Event) {
        this.stage.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouch, this)
        this.stage.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouch, this)
        this.stage.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouch, this)
    }    

    /**
     * oef
     */
    public onTouch(e: egret.TouchEvent)
    {
        
    }
    /**
     * oef
     */
    public oef()
    {
        
    }
}