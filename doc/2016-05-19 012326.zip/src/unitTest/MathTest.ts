/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../view/LineDrawer.ts" />
/// <reference path="../view/FruitView.ts" />
/// <reference path="../view/OrangeView.ts" />
/// <reference path="../view/SpaceView.ts" />
/// <reference path="TestBase.ts" />


/**
 * Test
 */
class MathTest extends TestBase
{
    public f: view.FruitView
    public sv:view.SpaceView
    public constructor()
    {
        super();

        console.log(Math.cos(0 * MathCore.RADIAN_DEGREE_RATIO))
        console.log(Math.cos(30 * MathCore.RADIAN_DEGREE_RATIO))
        console.log(Math.cos(45 * MathCore.RADIAN_DEGREE_RATIO))
        console.log(Math.cos(60 * MathCore.RADIAN_DEGREE_RATIO))
    }

    
}