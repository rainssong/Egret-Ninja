/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../view/LineDrawer.ts" />


/**
 * Test
 */
class LineDrawerTest extends TestBase
{
    public ld: view.LineDrawer
    public constructor()
    {
        super();

        this.ld = new view.LineDrawer();
        this.ld.startDraw(new egret.Point(0, 0));

        this.addChild(this.ld);
        
        this.ld.startDraw(new egret.Point(100, 100));
    }

    /**
     * oef
     */
    public onTouch(e: egret.TouchEvent)
    {
        switch (e.type) {
            case egret.TouchEvent.TOUCH_BEGIN:
                    this.ld.startDraw(new egret.Point(e.stageX, e.stageY));
                break;
            case egret.TouchEvent.TOUCH_MOVE:
                    this.ld.keepDraw(new egret.Point(e.stageX, e.stageY));
                break;
            case egret.TouchEvent.ENDED:
                
                break;
        
            default:
                break;
        }
        
    }
    /**
     * oef
     */
    public oef()
    {
        
        this.ld.update();
    }
}