class Singletons {
				public static eventBus:egret.EventDispatcher=new egret.EventDispatcher()

				public constructor()
				{
					
				}
}