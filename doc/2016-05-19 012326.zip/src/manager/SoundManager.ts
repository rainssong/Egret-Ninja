/// <reference path="../../libs/modules/res/RES.d.ts" />

/**
 * SoundManager
 */
class SoundManager
{

    // public static cutSound: egret.Sound
    // public static dropSound: egret.Sound
    // public static splatterSound: egret.Sound
    public static swipSoundChannel: egret.SoundChannel
    // public static throwSound: egret.Sound

    constructor()
    {


    }

    public static playCutSound()
    {
        RES.getRes("cut_mp3").play(0, 1);
    }

    public static playDropSound()
    {
        RES.getRes("drop_mp3").play(0, 1);
    }
    public static playSplatterSound()
    {
        RES.getRes("splatter_mp3").play(0, 1);
    }

    //不用
    // public static playSwipSound()
    // {
    //     RES.getRes("swip_mp3").play(0, 1);
    // }
    public static playThrowSound()
    {
        RES.getRes("throw_mp3").play(0, 1);
    }

}