/**
 *
 * @author 
 *
 */
class ApplicationManager {
    public static stageWidth:number=480;
    public static stageHeight: number=800;
	public constructor() {
    	
	}
}
