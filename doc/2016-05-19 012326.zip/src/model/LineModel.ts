module model {
	export class LineModel extends egret.HashObject {
		public sp:egret.Point;
		public ep:egret.Point;
		public thickness:number = 1;
		public alpha:number = 1;
		public color:number = 0xffffff;

		public constructor(sp:egret.Point,ep:egret.Point,thickness:number = 2)
		{
			super();
			this.sp = sp;
			this.ep = ep;
			this.thickness = thickness;
		}

		public update()
		{
			this.thickness--;
			this.alpha -= 0.1;
		}

	}
}

