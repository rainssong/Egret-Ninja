class ArrayCore extends egret.HashObject {
				public static LOWER_CASE_LETTER_ARR:Array<any>;
				public static UPPER_CASE_LETTER_ARR:Array<any>;
				public static UPPER_CASE_LETTER_INDEX_DIC:any;

				public constructor()
				{
					super();
				}

				public static concat(arr1:Array<any>,arr2:Array<any>):Array<any>
				{
					var arr:Array<any> = arr1.slice();
					arr.push.apply(null,arr2);
					return arr;
				}

				public static getIntArray(start:number = 0,end:number = 100):Array<any>
				{
					var arr:Array<any> = [];
					for(var i:number = start;start < end?(i <= end):(i >= end); start < end?i++:i--)
					{
						arr.push(i);
					}
					return arr;
				}

				public static getContentArray(content:any,length:number = 0):Array<any>
				{
					var arr:Array<any> = [];
					if(length == 0)
						return arr;
					for(var i:number = 0;i < length; i++)
					{
						arr.push(content);
					}
					return arr;
				}

				public static forEach(target:any,fun:any)
				{
					for(var t_key_a in target)
					{
						var t:any = target[t_key_a];
						t[fun]();
					}
				}

				public static getRandomizedArray(arr:any):any
				{
					var outputArr:any = arr.slice();
					var i:number = outputArr.length;
					var temp:any;
					var indexA:number = 0;
					var indexB:number = 0;
					while(i)
					{
						indexA = i - 1;
						indexB = Math.floor(Math.random() * i);
						i--;
						if(indexA == indexB)
							continue;
						temp = outputArr[indexA];
						outputArr[indexA] = outputArr[indexB];
						outputArr[indexB] = temp;
					}
					return outputArr;
				}

				public static getLightRandomizedArray(arr:Array<any>,times:number = 1):Array<any>
				{
					var outputArr:Array<any> = arr.slice();
					var length:number = outputArr.length;
					for(var i:number = 0;i < length - 1; i++)
					{
						if(Math.random() > 0.5)
						{
							var temp:any = outputArr[i];
							outputArr[i] = outputArr[i + 1];
							outputArr[i + 1] = temp;
						}
					}
					return outputArr;
				}

				public static switchElements(arr:Array<any>,index1:number,index2:number)
				{
					var elementA:any = <any>arr[index1];
					arr[index1] = arr[index2];
					arr[index2] = elementA;
				}

				public static sum(arr:any):number
				{
					var nSum:number = <any>0;
					for(var i:number = <any>0;i < arr.length; i++)
					{
						if(typeof (arr[i]) == "number")
						{
							nSum += arr[i];
						}
					}
					return nSum;
				}



			

				public static vectorToArray(vector:any):Array<any>
				{
					var array:Array<any> = new Array();
					var callback:Function = <any>function (item:any,index:number,vector:any):boolean
					{
						array.push(item);
						return true;
					};
					vector.every(callback);
					return array;
				}

				public static arrayToVector(array:Array<any>):Array<any>
				{
					return Array<any>(array);
				}

				






				public static merge(arr1:Array<any>,arr2:Array<any>):Array<any>
				{
					var arr:Array<any> = arr1.slice();
					for(var i:number = 0;i < arr2.length; i++)
					{
						if(arr.indexOf(arr2[i]) >= 0)
							continue;
						else
							arr.push(arr2[i]);
					}
					return arr;
				}

				public static removeByElement(arr:Array<any>,element:any)
				{
					if(arr.indexOf(element) > -1)
						arr.splice(arr.indexOf(element),1);
				}

				

			}
