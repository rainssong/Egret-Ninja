

class MathCore
{
    public static  DEGREE_RADIAN_RATIO:number = 180 / Math.PI;
    public static  RADIAN_DEGREE_RATIO:number = Math.PI / 180;
    
    
    public static randomSelect(aov: any): any 
    {
        return aov[Math.floor(aov.length * Math.random())];
	}
	
    public static getRandomNumber(min: number,max: number): number {
        return Math.random() * (max - min) + min;
	}
				
     public static getRandomInt(min:number=-Infinity,max:number=Infinity):number
     {
     	return Math.floor(Math.random() * (max - min+1) + min);
     }

     public static getRangedNumber(num:number, min:number=-Infinity, max:number = Infinity):number
		{
			if (min > max)
			{
				var tmp:number = min;
				min = max;
				max = tmp;
			}
			if (isNaN(min))
				min = -Infinity;
			if (isNaN(max))
				max = Infinity;
			
			return Math.max(min, Math.min(num, max));
		}
}