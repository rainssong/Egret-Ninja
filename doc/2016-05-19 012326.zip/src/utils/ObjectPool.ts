/// <reference path="Constructor.ts" />


class ObjectPool
{
	private static _pool: Array<any> = new Array<any>();

	private _template: any;

	private _list: Array<any>;

	public constructor(value: any)
	{
		this._template = value;
		this._list = new Array<any>();
	}

	public getObject(params: Array<any> = null): any
	{
		if (this._list.length > 0)
		{
			return this._list.shift();
		}
		return construction (this._template,params);
	}

	public returnObject(value: any): void
	{
		this._list.push(value);
	}

	public dispose(): void
	{
		this._list = null;
		this._template = null;
	}

	public static getPool(value: any): ObjectPool
	{
		if (!ObjectPool._pool[value])
		{
			ObjectPool._pool[value] = new ObjectPool(value);
		}
		return ObjectPool._pool[value];
	}

	public static getObject(cls: any, params: any = []): any
	{
		return ObjectPool.getPool(cls).getObject(params);
	}

	public static returnObject(value: any): void
	{
		return ObjectPool.getPool(value.constructor).returnObject(value);
	}

	public static dispose(cls: any = null): void
	{
		if (cls) ObjectPool.getPool(cls).dispose();
		else ObjectPool._pool = [];
	}
}
