/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="LifeEntityView.ts" />

module view
{
    export class JuiceView extends view.LifeEntityView {
		private _skin:egret.Bitmap;

		public constructor()
		{
			super();
		}

		public init()
		{
            this._skin = new egret.Bitmap();
			this._skin.fillMode = egret.BitmapFillMode.SCALE;
            this.addChild(this._skin);
			super.init();
		}

		/**
		 * reset
		 */
		public reset()
		{
			this._lifeTime = 6;
			this._skin.alpha = 0.7;
		}

		public update(deltaTime:number = 1 / 60)
		{
			super.update(deltaTime);
			//alpha=life*speed
			if (this._lifeTime <= 0.7/0.25)
			{
				this._skin.alpha = this._lifeTime * 0.25;
				this.y += deltaTime * 5;
			}	
		}

		public get texture(): egret.Texture
		{
			return this._skin.texture;
		}

        public set texture(value: egret.Texture)
		{
			this._skin.texture = value;
			
			this._skin.x = -this._skin.width * 0.5;
			this._skin.y = -this._skin.height * 0.5;
			this.reset();
		}

	}
}
