/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../../libs/modules/res/res.d.ts" />
/// <reference path="FruitView.ts" />

module view
{
	export class OrangeView extends view.FruitView {

		public constructor()
		{
			super();
			this._skin.texture=RES.getRes("orange_png");
			this._type = "orange";
			this._color = 0xFFDC88;
			this._skin.x = -40;
			this._skin.y = -40;
			this.frontTex = RES.getRes("orangef_png");
			this.backTex = RES.getRes("orangeb_png");
			this.juiceTex = RES.getRes("orangej_png");
			this.particleTex = RES.getRes("orangep_png");
			this.backOffset = new egret.Point(-15,0);
			this.frontOffset = new egret.Point(+15,0);
			this.juiceOffset = new egret.Point(+15,0);
			
		}

	}
}
