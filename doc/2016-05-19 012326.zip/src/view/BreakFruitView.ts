module view {
	export class BreakFruitView extends view.EntityView {
		private _skin:egret.Bitmap;

		public constructor()
		{
			super();
			this._skin = new egret.Bitmap();
			
			this.addChild(this._skin);
		}

		public get skin(): egret.Bitmap
		{
			return this._skin;
		}

        public get texture(): egret.Texture
		{
			return this._skin.texture;
		}

        public set texture(value: egret.Texture)
		{
			this._skin.texture = value;;
			this._skin.x = -this._skin.width * 0.5;
			this._skin.y = -this._skin.height * 0.5;
		}

	}
}
