module view {
    /**
     * 简易物理空间
     */ 
	export class SpaceView extends egret.Sprite {
		
		private _entitys:Array<view.EntityView>;
        public gravity:number=9.8;

		public constructor()
		{
			super();
			this._entitys = new Array<view.EntityView>();
		}

		public update(deltaTime:number = 1 / 60)
		{
			for(var entity_key_a in this._entitys)
			{
				var entity:view.EntityView = this._entitys[entity_key_a];
				entity.update(deltaTime);
			}
		}

		public addEntity(entity:view.EntityView)
		{
			
            this.addChildAt(entity,Math.max(entity.z,0));
			entity.environment = this;
			if(this._entitys.indexOf(entity) == -1)
				this._entitys.push(entity);
		}

		public removeEntity(entity:view.EntityView)
		{
            this.removeChild(entity);
			entity.environment = null;
			var index:number = this._entitys.indexOf(entity);
			if(index >= 0)
				this._entitys.splice(index,1);
		}

		public removeAllEntity()
		{
			while(this._entitys.length)
			{
				this.removeEntity(this._entitys[0]);
			}
		}

		public get entitys():Array<view.EntityView>
		{
			return this._entitys;
		}

		public destroy()
		{
			this.removeAllEntity();
		}

	}
}
