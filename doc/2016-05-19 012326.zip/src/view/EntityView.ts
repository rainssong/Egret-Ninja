/// <reference path="../../libs/modules/egret/egret.d.ts" />


module view
{
	export class EntityView extends egret.Sprite {
		protected _type:string = "entity";
		protected _environment:view.SpaceView;
        public speed: egret.Point= new egret.Point();
        public velocity: egret.Point = new egret.Point();
        public angSpeed: number = 0;
		public z: number = 10;

		public constructor()
		{
			super();
			this.init();
		}

		public init()
		{
			this.reset();
		}

		public reset()
		{
    		
		}

		public update(deltaTime:number = 1 / 60)
		{
			if(this._environment == null)
				return ;
			this.speed.y += this._environment.gravity * deltaTime;
			this.x += this.speed.x * deltaTime;
			this.y += this.speed.y * deltaTime;
			this.rotation += this.angSpeed * deltaTime;
			
		}

		public remove()
		{
			if(this._environment)
				this._environment.removeEntity(this);
			ObjectPool.returnObject(this);
		}

		public get environment():view.SpaceView
		{
			return this._environment;
		}

		public set environment(value:view.SpaceView)
		{
			this._environment = value;
		}

	}
}
