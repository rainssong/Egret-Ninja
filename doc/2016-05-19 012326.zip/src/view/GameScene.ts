/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../../libs/modules/res/res.d.ts" />
/// <reference path="SpaceView.ts" />
/// <reference path="OrangeView.ts" />
/// <reference path="KiwiView.ts" />
/// <reference path="../manager/Singletons.ts" />
/// <reference path="../manager/SoundManager.ts" />
/// <reference path="../utils/MathCore.ts" />
/// <reference path="LineDrawer.ts" />


module view
{
    export class GameScene extends egret.Sprite
	{
		private _fruitSpace: view.SpaceView;
		private _effectSpace: view.SpaceView;
		private _lineDrawer: view.LineDrawer;
		private _isDown: boolean = false;
		private _freezeTime: number = 0;
		private _life: number = 3;
		private _bg: egret.Bitmap;
		private _uiLayer: egret.Sprite;
		//		private _lifeSign:LifeSign;
		//		private _timeProgress:me.rainui.components.ProgressBar;
		private _score: number = 0;
		private _gameTime: number = 0;
		private _isPaused: boolean = true;
		private _isOver: boolean = false;
		//		private _gameOverView:GameOverSKin;
        private _scoreLabel: egret.TextField;
        private _timeLabel: egret.TextField
        private _lifeLabel: egret.TextField
		private _fruits: Array<number>;
        private fruitClasses: Array<any> = [OrangeView, KiwiView];

		private _touchX: number = 0;
        private _touchY: number = 0;

        private lastTime: number = 0;
        private newTime: number = 0;

		public constructor()
		{
			super();
			this.createChildren();
		}

		protected createChildren()
		{
			this._bg = new egret.Bitmap(RES.getRes("bg_png"));
			this.addChild(this._bg);

			this._fruitSpace = new view.SpaceView();
			this.addChild(this._fruitSpace);
			this._fruitSpace.gravity = 1600;
			this._effectSpace = new view.SpaceView();
            this.addChild(this._effectSpace);
			this._effectSpace.touchChildren = this._effectSpace.touchChildren = false;
			this._lineDrawer = new view.LineDrawer();
			this.addChild(this._lineDrawer);

			this._lifeLabel = new egret.TextField();
            this._lifeLabel.text = "";
            this._lifeLabel.textAlign = egret.HorizontalAlign.RIGHT;
            this._lifeLabel.textColor = 0xff0000;
			this._lifeLabel.width = 120
			this._lifeLabel.x = ApplicationManager.stageWidth - this._lifeLabel.width - 20;
			this._lifeLabel.y = 20;
			this.addChild(this._lifeLabel);

            this._scoreLabel = new egret.TextField();
            this._scoreLabel.text = "0";
            this._scoreLabel.textAlign = egret.HorizontalAlign.LEFT;
            this._scoreLabel.textColor = 0xffffff
            this._scoreLabel.x = 20;
            this._scoreLabel.y = 20;
            this.addChild(this._scoreLabel);
			//			this._gameOverView = new GameOverSKin();
			//			this._gameOverView["addEventListener"](egret.TouchEvent.TOUCH_TAP, this.onGameOverClick,this));
			this._fruits = new Array<number>();

			this.touchEnabled = true;

			this.updateUI();

			this.initialize()
		}

		public restart()
		{
			this.reset();
			this.start();
		}

		protected initialize()
		{

			this.addEventListener(egret.Event.ENTER_FRAME, this.onEnterFrame, this);
			Singletons.eventBus.addEventListener("miss", this.onMiss, this);
			Singletons.eventBus.addEventListener("break2", this.onBreak2, this);
			Singletons.eventBus.addEventListener("cut", this.onCut, this);
			this.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchDown, this);
            this.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchUp, this);
            this.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this);
            this.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchUp, this);
			this.reset();
		}

		private onCut(e: egret.Event)
		{
			this._score += e.data;
			this._scoreLabel.text = this._score.toFixed(0);
			SoundManager.playCutSound();
		}

		private onBreak2(e: egret.Event)
		{
			SoundManager.playSplatterSound();
		}

		private onMiss(e: egret.Event)
		{
			this._life--;
			SoundManager.playDropSound();
		}

		private onTouchUp(e: egret.TouchEvent)
		{
			this._isDown = false;
			this._touchX = null;
			this._touchY = null;
		}

		private onTouchDown(e: egret.TouchEvent)
		{
			this._isDown = true;
			this._touchX = e.stageX;
			this._touchY = e.stageY;
			this._lineDrawer.startDraw(new egret.Point(e.stageX, e.stageY));
		}

		private onTouchMove(e: egret.TouchEvent)
		{
			// this._lineDrawer.keepDraw(new egret.Point(e.stageX,e.stageY));
			this._touchX = e.stageX;
			this._touchY = e.stageY;
		}

		public updateUI()
		{

			this._lifeLabel.text = this._life == 3 ? "" : this._life == 2 ? "X" : this._life == 1 ? "XX" : "XXX";
			this._gameTime.toFixed(1) + "s";
		}

		public onEnterFrame(e: egret.Event): void
		{
			this.newTime = egret.getTimer();
			this.update((this.newTime - this.lastTime) * 0.001);
            this.lastTime = this.newTime;
		}

		private update(deltaTime: number = 1 / 60)
		{

			var currentPoint: egret.Point = new egret.Point(this._touchX, this._touchY);
			this.updateUI();
			if (this._isPaused)
				return;

			this._fruitSpace.update(deltaTime);
			this._effectSpace.update(deltaTime);
			this._lineDrawer.update();
			if (this._isOver)
				return;
			this._gameTime += deltaTime;

			if (this._life == 0)
				this.gameOver();

			if (this._isDown)
			{
				this._lineDrawer.keepDraw(currentPoint);
				//切割角度
				var angle: number = Math.atan2(this._lineDrawer.cp.y - this._lineDrawer.sp.y, this._lineDrawer.cp.x - this._lineDrawer.sp.x);
				//滑动速度
				var ms: number = egret.Point.distance(this._lineDrawer.cp, this._lineDrawer.sp) / deltaTime;
				if (ms > 1000)
				{
					
					for (var i: number = 0; i < this._fruitSpace.entitys.length; i++)
					{
						var e: view.EntityView = <any>this._fruitSpace.entitys[i];
						if (e instanceof view.FruitView)
						{
							var f: view.FruitView = e;
							//防漏点（2333）
							var braPoint: egret.Point = egret.Point.interpolate(this._lineDrawer.cp, this._lineDrawer.sp, 0.5);
							if (f.hitTestPoint(currentPoint.x, currentPoint.y) || f.hitTestPoint(braPoint.x, braPoint.y))
							{
								f.cut(MathCore.DEGREE_RADIAN_RATIO * angle);

								var fl: view.FlashView = ObjectPool.getObject(view.FlashView);
								fl.reset();
								fl.rotation = MathCore.DEGREE_RADIAN_RATIO * angle;
								this._fruitSpace.addEntity(fl);
								fl.x = currentPoint.x;
								fl.y = currentPoint.y;

								// }
							}
						}
					}
				}
			}
			var rnd: number = Math.random();

			if (rnd < 0.023)
			{

				var fruitClass: any = MathCore.randomSelect(this.fruitClasses);
                var fruitView: view.FruitView = new fruitClass();
				fruitView.reset();
				this._fruitSpace.addEntity(fruitView);
				fruitView.x = MathCore.getRandomInt(20, ApplicationManager.stageWidth - 120);
				fruitView.y = ApplicationManager.stageHeight;
				fruitView.rotation = MathCore.getRandomNumber(-360, 360);
				fruitView.speed.x = MathCore.getRandomInt(-300, 300);
				fruitView.speed.y = MathCore.getRandomInt(-1600, -1100);
				fruitView.angSpeed = MathCore.getRandomNumber(-180, 180);
				SoundManager.playThrowSound();
				//				SoundManager.getInstance().playSound("throw");
				// console.log("fruit left:" + this._fruits.length);
			}
		}

		public reset()
		{
			this._life = 3;
			this._score = 0;
			this._scoreLabel.text = this._score.toFixed(0);
			this._gameTime = 0;
			this._isOver = false;
			var normalFruits: Array<any> = [0, 1, 2, 3, 4, 5];
			this._fruits.length = 0;
			// for(var i:number = 0;i < 25; i++)
			// {
			// 	this._fruits.push(MathCore.randomSelect(normalFruits));
			// }
			// this._fruits = ArrayCore.getRandomizedArray(this._fruits);
			// this._fruits.splice(13,0,6);
			// this._fruits.splice(21,0,7);
			// for(var j:number = 0;j < 20; j++)
			// {
			// 	this._fruits.push(MathCore.randomSelect(normalFruits));
			// }
			this._fruitSpace.removeAllEntity();
			this._effectSpace.removeAllEntity();
		}

		public pause()
		{
			this._isPaused = true;
		}

		public resume()
		{
			this._isPaused = false;
		}

		public gameOver()
		{
			alert("Game Over, Your Score:" + this._score);
			this._isOver = true;
			this._isPaused = true;
			this.restart();
		}

		public start()
		{
			this.lastTime = egret.getTimer();
			this.resume();
			this._isOver = false;
		}

		public destroy()
		{

			this._fruitSpace.destroy();
			this._effectSpace.destroy();
			Singletons.eventBus.removeEventListener("miss", this.onMiss, this);
			Singletons.eventBus.removeEventListener("break2", this.onBreak2, this);
			Singletons.eventBus.removeEventListener("cut", this.onCut, this);
			this.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchDown, this);
			this.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchUp, this);
			this.removeEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, this.onTouchUp, this);

		}

	}
}
