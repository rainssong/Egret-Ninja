/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="../model/LineModel.ts" />

module view
{
	export class LineDrawer extends egret.Sprite {
		private _lines:Array<model.LineModel>;
		private _sp:egret.Point = null;
		private _cp:egret.Point = null;
		private _shape:egret.Shape = new egret.Shape();

		public constructor()
		{
			super();
			this._lines = new Array<model.LineModel>();
			this.addChild(this._shape);
		}

		public startDraw(p:egret.Point)
		{
			this._sp = p;
			this._cp = p;
		}

		public keepDraw(p:egret.Point)
		{
			this._sp = this._cp;
			this._cp = p;
			var l:model.LineModel = new model.LineModel(this._sp,this._cp,10);
			l.alpha = 1;
			this._lines.push(l);
		}

		public update()
		{
			this._shape.graphics.clear();
			for(var i:number = this._lines.length - 1;i >= 0; i--)
			{
				var l:model.LineModel = this._lines[i];
				this._shape.graphics.lineStyle(l.thickness + 4,l.color * 0.5,l.alpha * 0.8);
				this._shape.graphics.moveTo(l.sp["x"],l.sp["y"]);
				this._shape.graphics.lineTo(l.ep["x"], l.ep["y"]);
				// 减少作画，提高效率
				// this._shape.graphics.lineStyle(l.thickness,l.color);
				// this._shape.graphics.moveTo(l.sp["x"],l.sp["y"]);
				// this._shape.graphics.lineTo(l.ep["x"],l.ep["y"]);
				l.update();
				if(l.thickness <= 0)
					this._lines.splice(i,1);
			}
			
		}

		public get cp():egret.Point
		{
			return this._cp;
		}

		public get sp():egret.Point
		{
			return this._sp;
		}

		public destroy()
		{
			this._lines.length = 0;
		}

	}
}
