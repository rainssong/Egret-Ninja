/// <reference path="EntityView.ts" />


module view
{
    export class LifeEntityView extends view.EntityView {
		protected _lifeTime:number = 0;

		public constructor()
		{
			super();
		}

		public update(deltaTime:number = 1 / 60)
		{
			this._lifeTime -= deltaTime;
			if(this._lifeTime <= 0)
				this.remove();
		}

	}
}
