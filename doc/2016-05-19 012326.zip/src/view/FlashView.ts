/// <reference path="../../libs/modules/egret/egret.d.ts" />
/// <reference path="LifeEntityView.ts" />

module view
{
    export class FlashView extends view.LifeEntityView {
		private _skin:egret.Bitmap;

		public constructor()
		{
			super();
		}

		public init()
		{
            this._skin = new egret.Bitmap(RES.getRes("flash_png"));
			this._skin.fillMode = egret.BitmapFillMode.SCALE;
			this._skin.x = -this._skin.width * 0.5;
			this._skin.y = -this._skin.height * 0.5;
            this.addChild(this._skin);
			super.init();
		}

		/**
		 * reset
		 */
		public reset()
		{
			this._lifeTime = 0.3;
			this._skin.alpha = 1;
		}

		public update(deltaTime:number = 1 / 60)
		{
			super.update(deltaTime);
			if (this._lifeTime <= 0.3)
			{
				this._skin.alpha = this._lifeTime*3.3;
			}	
		}

	}
}
